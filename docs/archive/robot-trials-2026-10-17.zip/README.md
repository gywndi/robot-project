# SO-ARM101 로봇 트라이얼 / BMT

간단한 관절 동작을 실행하고 목표 위치·실제 위치·반복성·통신 오류를 기록하는 실험 프로젝트입니다. 6개 관절을 지원하며 한 번에 하나만 시험합니다. 기본 실행은 mock이며 실물 자동 시작은 없습니다.

## 1. 설치

Python 3.11을 준비하고 저장소 루트에서 실행합니다.

```bash
python3.11 -m venv .venv
source .venv/bin/activate
```

mock에는 외부 패키지가 필요 없습니다. 실물 연결용 LeRobot 설치는 [설치](docs/installation.md)를 참고합니다.

## 2. 준비

[준비](docs/preparation.md)와 [안전](docs/safety.md)을 확인합니다. USB 포트는 코드에 저장하지 않습니다. 연결 전 직접 식별한 경로를 `--port` 또는 `FOLLOWER_PORT`로 전달합니다. 누락 시 실물 연결을 거부합니다. [환경변수 예시](config/ports.env.example)는 비어 있으며 자동 로드되지 않습니다.

[관절 설정](config/robot.toml)의 step/offset은 raw ticks 단위의 소프트웨어 시험 범위입니다. 기계적 안전 한계나 보정된 각도가 아닙니다.

## 3. 구현

| 위치 | 역할 |
|---|---|
| `src/robot_trial/transport.py` | mock / LeRobot 통신 |
| `src/robot_trial/safety.py` | raw tick 이동량 검사 |
| `src/robot_trial/controller.py` | RobotController, 단일 관절 이동 및 결과 읽기 |
| `src/robot_trial/cli.py` | 인자·설정·실물 동의 처리 |
| `config/robot.toml` | 관절별 시험 설정 |
| `tests/` | mock 안전 테스트 |

실제 포트·장치 ID·개인별 경로의 코드 하드코딩은 [AGENTS.md](AGENTS.md)에서 금지합니다. 자세한 순서는 [BMT 계획](docs/roadmap.md)을 참고합니다.

## 4. 테스트

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

자동 테스트는 하드웨어에 접근하지 않습니다. 실물 결과는 [시험 기록](docs/test-results.md)에 명령·측정값·물리적 관찰과 함께 남깁니다.

## 5. 동작

기본 모의 위치 읽기:

```bash
PYTHONPATH=src python -m robot_trial.cli read
```

모의 집게 / 손목 회전:

```bash
PYTHONPATH=src python -m robot_trial.cli move --joint gripper --delta-ticks 5
PYTHONPATH=src python -m robot_trial.cli move --joint wrist_roll --delta-ticks -5
```

관절 선택: `shoulder_pan`, `shoulder_lift`, `elbow_flex`, `wrist_flex`, `wrist_roll`, `gripper`.

실물 읽기와 단일 이동은 아래 형식으로 실행합니다. `FOLLOWER_PORT`는 로컬에서 확인한 값으로 먼저 설정해야 합니다.

```bash
PYTHONPATH=src python -m robot_trial.cli read --live --port "$FOLLOWER_PORT"
PYTHONPATH=src python -m robot_trial.cli move --live --port "$FOLLOWER_PORT" --joint gripper --delta-ticks 5 --arm-supported
```

실물 이동은 `MOVE 관절이름` 입력 후 시작합니다. 현재 위치를 목표로 기록 → 대상 관절만 토크 ON → 상대 이동 목표 전송 → 사용자가 관찰 후 Enter → 실제 위치 읽기 → 대상 토크 OFF 순서입니다. 실행 전 모든 관절의 토크가 꺼져 있어야 하며, 켜져 있으면 변경 없이 거부합니다. 팔은 먼저 물리적으로 지지해야 합니다. 종료 시 전체 관절 토크를 변경하지 않습니다.

손목도 같은 명령으로 선택할 수 있지만 과거 약 360° 회전 문제는 미해결입니다. 손목 실물 시험 전 원인을 확인해야 합니다. Ctrl+C는 하드웨어 비상 정지가 아닙니다. 이 변경에서는 실물 시험을 실행하지 않았습니다.

### 6개 관절 왕복 트라이얼

```bash
# mock: 관절 하나씩 +5 raw ticks 이동 후 시작 위치로 복귀, 각 1회
PYTHONPATH=src python -m robot_trial.roundtrip --delta-ticks 5
```

실물용 읽기 전용 사전 진단:

```bash
PYTHONPATH=src python -m robot_trial.diagnostics --port "$FOLLOWER_PORT"
```

실물 왕복은 `--live --port "$FOLLOWER_PORT" --arm-supported`를 추가하고 `ROUNDTRIP ALL`로 해당 실행을 승인해야 합니다. 기본값은 관절당 +5 ticks이며 이동량은 인자로 명시합니다. 별도의 `config/all-joints-visibility-trial.toml`은 사용자가 동의한 +20 ticks 시험 프로필입니다. 기계적 한계를 검증한 값이 아닙니다. 6개 관절을 동시에 켜지 않으며 관절별 토크 OFF를 확인한 후 다음으로 넘어갑니다. 오류 시 이후 관절은 실행하지 않습니다.

왕복 프로필의 방향별 대기 합계는 약 10초이며 통신 시간은 별도입니다. 무한 반복이나 관절별 10초 반복은 수행하지 않습니다. 최신 실측은 [시험 기록](docs/test-results.md)을 참고합니다.

### 저속·저토크 범위 측정 준비

`robot_trial.range_trial`은 지정한 유한 경로를 실행하며 대상 관절의 SRAM 토크 제한·속도·가속도만 임시 변경합니다. 원래 값을 기록하고 종료 시 대상 토크 OFF 및 설정 복원을 읽기로 확인합니다. 통신 장애에서는 복원 성공을 보장할 수 없습니다. EPROM 범위/보정/ID는 변경하지 않습니다.

```bash
PYTHONPATH=src python -m robot_trial.range_trial --config config/gripper-range-stage1.toml --output logs/gripper-range-mock.jsonl
```

기존 로그는 덮어쓰지 않습니다. 실물 실행에는 별도 `--live --port "$FOLLOWER_PORT" --arm-supported`와 `RANGE gripper` 동의가 필요합니다. `gripper-range-stage1.toml`은 ±40 ticks, `gripper-range-stage2.toml`은 ±120 ticks 제안입니다. 2단계는 사용자 동의하에 실물 1회 실행했으며, 어느 프로필도 기계적 안전 범위로 검증된 값은 아닙니다. 현장 관찰 없이는 시험 구간을 검증 완료로 저장하지 않습니다.

### 다음 개발 방향

Leader는 사용하지 않습니다. Follower 단독으로 키보드 jog → 세 자세 저장 → 경로 미리보기 → 유한 시퀀스 재생 → 반복 BMT를 구현할 계획입니다. [개발 계획](docs/roadmap.md)과 [공개 동작 데이터 검토](docs/motion-data.md)를 참고합니다. 이 단계의 새 모듈은 아직 구현하지 않았습니다.
