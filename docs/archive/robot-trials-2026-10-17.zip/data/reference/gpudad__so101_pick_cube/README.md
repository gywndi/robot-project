---
license: apache-2.0
task_categories:
- robotics
tags:
- lerobot
- so101
- manipulation
- pick-and-place
- simulation
- mujoco
configs:
- config_name: default
  data_files:
  - split: train
    path: data/**/*.parquet
---

# SO-101 Pick Cube Dataset

A large-scale robotics manipulation dataset featuring the SO-101 robot arm performing pick-and-place tasks in MuJoCo simulation. The robot learns to pick up a cube and place it into a bin.

![Camera Angles](camera_angles.png)

## Dataset Details

| Property | Value |
|----------|-------|
| Robot | SO-101 (6-DoF arm with gripper) |
| Task | Pick cube and place in bin |
| Episodes | 10,993 |
| Total Frames | 1,456,901 |
| FPS | 30 |
| Cameras | 3 (front, overhead, wrist) |
| Resolution | 640x480 |
| Format | LeRobot v3.0 |

## Cameras

- **Front Camera**: External view of the robot and workspace
- **Overhead Camera**: Top-down view of the workspace  
- **Wrist Camera**: Mounted on the robot's wrist for close-up manipulation view

## State/Action Space

6 joints: `shoulder_pan`, `shoulder_lift`, `elbow_flex`, `wrist_flex`, `wrist_roll`, `gripper`

## Usage with LeRobot

```python
from lerobot.common.datasets.lerobot_dataset import LeRobotDataset

dataset = LeRobotDataset("gpudad/so101_pick_cube")
print(f"Episodes: {dataset.num_episodes}")
print(f"Frames: {dataset.num_frames}")
```

## Training

```bash
python lerobot/scripts/train.py \
  --dataset.repo_id=gpudad/so101_pick_cube \
  --policy.type=act \
  --env.type=so101_pick_cube
```

## License

Apache 2.0
