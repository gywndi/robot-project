"""Bounded, synthetic relative-offset preview; never exports live motor targets."""
import argparse
import json
from pathlib import Path
import tomllib
from .episode_analyze import analyze
from .transport import JOINTS


def build_preview(info, rows, caps):
    analyze(info, rows)
    names = [name.removesuffix('.pos') for name in info['features']['action']['names']]
    if set(names) != set(JOINTS) or set(caps) != set(JOINTS):
        raise ValueError('Explicit six-joint mapping and caps required')
    for cap in caps.values():
        if type(cap) is not int or cap <= 0:
            raise ValueError('Preview caps must be positive integer ticks')
    # Per-axis amplitude scaling preserves only waveform shape, not physical motion.
    differences = {joint: [row['action'][names.index(joint)] - rows[0]['action'][names.index(joint)]
                           for row in rows] for joint in JOINTS}
    amplitudes = {joint: max(abs(v) for v in values) for joint, values in differences.items()}
    frames = []
    for i, row in enumerate(rows):
        offsets = {joint: round(differences[joint][i] / amplitudes[joint] * caps[joint])
                   if amplitudes[joint] else 0 for joint in JOINTS}
        if any(abs(offsets[joint]) > caps[joint] for joint in JOINTS):
            raise ValueError('Synthetic preview cap exceeded')
        frames.append({'timestamp': row['timestamp'], 'synthetic_offset_ticks': offsets})
    return {'hardware_replay_allowed': False,
            'purpose': 'Waveform-shape preview only; independent scaling changes geometry and task meaning',
            'absolute_motor_targets': None, 'frames': frames}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    info = json.loads((args.directory/'info.json').read_text())
    rows = json.loads((args.directory/'episode-000000.json').read_text())
    caps = tomllib.loads(args.config.read_text())['preview_offset_caps_ticks']
    result = build_preview(info, rows, caps)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'preview_frames': len(result['frames']),
                      'hardware_replay_allowed': False, 'absolute_motor_targets': None}))


if __name__ == '__main__':
    main()
