"""Single-joint trial controller; construction does not connect or write."""
from .safety import Limits
from .transport import Transport, JOINTS


class RobotController:
    def __init__(self, transport: Transport, limits: Limits):
        self.transport = transport
        self.limits = limits

    def positions(self):
        return {joint: self.transport.read(joint) for joint in JOINTS}

    def move(self, joint: str, delta: int, *, approved: bool = False):
        if not approved:
            raise PermissionError('Explicit operator approval is required')
        if joint not in JOINTS:
            raise ValueError('Unknown joint')
        bus = self.transport
        start = bus.read(joint)
        target = self.limits.check(start, start, delta)
        if any(bus.torque(name) != 0 for name in JOINTS):
            raise RuntimeError('Trial requires all joints initially torque-off; support the arm first')
        try:
            bus.write(joint, start)
            bus.enable(joint)
            bus.write(joint, target)
            # Operator observes the joint before cleanup; injected by the CLI below.
            self.observe()
            actual = bus.read(joint)
            return {'joint': joint, 'start_ticks': start, 'target_ticks': target,
                    'actual_ticks': actual, 'error_ticks': actual - target}
        finally:
            bus.disable(joint)

    def observe(self):
        """Default mock observation. Live CLI overrides with an operator prompt."""
