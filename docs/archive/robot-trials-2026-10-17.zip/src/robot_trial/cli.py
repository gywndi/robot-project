import argparse
import json
import os
from pathlib import Path
import tomllib
from .controller import RobotController
from .safety import Limits
from .transport import JOINTS, LeRobotTransport, MockTransport


def main():
    parser = argparse.ArgumentParser(description='SO-ARM101 trial; default is mock')
    parser.add_argument('action', choices=('read', 'move'), nargs='?', default='read')
    parser.add_argument('--live', action='store_true')
    parser.add_argument('--joint', choices=JOINTS)
    parser.add_argument('--arm-supported', action='store_true', help='Operator confirms physical arm support')
    parser.add_argument('--port', default=os.getenv('FOLLOWER_PORT'))
    parser.add_argument('--delta-ticks', type=int)
    parser.add_argument('--config', type=Path, default=Path('config/robot.toml'))
    args = parser.parse_args()
    config = tomllib.loads(args.config.read_text())
    if args.action == 'move' and not args.joint:
        parser.error('move requires --joint')
    cfg = config[args.joint or 'gripper']
    limits = Limits(cfg['max_offset_ticks'], cfg['max_step_ticks'])
    if args.action == 'move' and args.delta_ticks is None:
        parser.error('move requires --delta-ticks')
    if args.action == 'move':
        limits.check(0, 0, args.delta_ticks)
    if args.live and not args.port:
        parser.error('--live requires --port or FOLLOWER_PORT')
    if args.live and args.action == 'move':
        if not args.arm_supported:
            parser.error('Live motion requires --arm-supported; support gravity-loaded joints before proceeding')
        print('Support the arm. Keep physical power cutoff reachable. Ctrl+C is not an E-stop.')
        print(f'Only {args.joint} will move; its torque is disabled on exit. Support the arm and secure held objects.')
        print(f'Raw-tick delta: {args.delta_ticks}; software limits are not measured mechanical limits.')
        if input(f'Type MOVE {args.joint} to approve this trial: ').strip() != f'MOVE {args.joint}':
            parser.exit(message='Cancelled\n')
    transport = LeRobotTransport(args.port) if args.live else MockTransport(cfg['mock_start_ticks'])
    controller = RobotController(transport, limits)
    if args.live and args.action == 'move':
        controller.observe = lambda: input('Observe motion, then press Enter to read position and release target joint torque: ')
    try:
        if args.live:
            transport.connect()
        result = controller.positions() if args.action == 'read' else controller.move(args.joint, args.delta_ticks, approved=True)
        print(json.dumps({'mode': 'live' if args.live else 'mock', 'result': result}))
    finally:
        if args.live:
            transport.close()


if __name__ == '__main__':
    main()
