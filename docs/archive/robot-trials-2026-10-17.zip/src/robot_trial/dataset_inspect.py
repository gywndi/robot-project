"""Offline inspection of public dataset metadata. No hardware or network access."""
import argparse
import json
from pathlib import Path
from .transport import JOINTS


def inspect_metadata(info, source):
    features = info.get('features', {})
    action = features.get('action', {})
    names = action.get('names') or []
    normalized = [name.removesuffix('.pos') for name in names]
    if len(set(normalized)) != len(normalized):
        raise ValueError('Duplicate joint names')
    compatible_names = set(normalized) == set(JOINTS)
    mapping = {joint: normalized.index(joint) for joint in JOINTS} if compatible_names else None
    return {
        'source': source, 'robot_type': info.get('robot_type'),
        'format': info.get('codebase_version'), 'fps': info.get('fps'),
        'episodes': info.get('total_episodes'), 'frames': info.get('total_frames'),
        'action_names': names, 'action_shape': action.get('shape'),
        'canonical_joint_to_source_index': mapping,
        'action_units': 'unverified', 'absolute_or_delta': 'unverified',
        'hardware_replay_allowed': False,
        'note': 'Name mapping alone does not establish units, calibration, control semantics or safe trajectories.'
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    info = json.loads((args.directory / 'info.json').read_text())
    source = json.loads((args.directory / 'source.json').read_text())
    print(json.dumps(inspect_metadata(info, source), indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
