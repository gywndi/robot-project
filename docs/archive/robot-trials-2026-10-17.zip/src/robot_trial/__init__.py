"""SO-ARM101 trials. Importing performs no hardware I/O."""
