"""Raw-tick software envelope; no claim of mechanical safety."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Limits:
    max_offset_ticks: int
    max_step_ticks: int

    def __post_init__(self):
        if any(type(v) is not int for v in (self.max_offset_ticks, self.max_step_ticks)):
            raise ValueError('Limits must be integer raw ticks')
        if not 0 < self.max_step_ticks <= self.max_offset_ticks:
            raise ValueError('Require 0 < max_step_ticks <= max_offset_ticks')

    def check(self, start: int, current: int, delta: int) -> int:
        if type(delta) is not int or not 0 < abs(delta) <= self.max_step_ticks:
            raise ValueError('Step exceeds configured raw-tick limit')
        target = current + delta
        if any(abs(value - start) > self.max_offset_ticks for value in (current, target)):
            raise ValueError('Startup-relative software envelope exceeded')
        return target
