"""Transport only; hardware dependency is imported on explicit live connection."""
from typing import Protocol

JOINTS = ('shoulder_pan', 'shoulder_lift', 'elbow_flex',
          'wrist_flex', 'wrist_roll', 'gripper')


class Transport(Protocol):
    def read(self, joint: str) -> int: ...
    def torque(self, joint: str) -> int: ...
    def write(self, joint: str, target: int) -> None: ...
    def enable(self, joint: str) -> None: ...
    def disable(self, joint: str) -> None: ...


class MockTransport:
    def __init__(self, start: int = 2470):
        self.positions = dict.fromkeys(JOINTS, start)
        self.enabled = dict.fromkeys(JOINTS, 0)
        self.commands = []

    def read(self, joint):
        return self.positions[joint]

    def torque(self, joint):
        return self.enabled[joint]

    def write(self, joint, target):
        self.commands.append(('goal', joint, target))
        self.positions[joint] = target

    def enable(self, joint):
        self.commands.append(('enable', joint))
        self.enabled[joint] = 1

    def disable(self, joint):
        self.commands.append(('disable', joint))
        self.enabled[joint] = 0


class LeRobotTransport:
    def __init__(self, port: str):
        if not isinstance(port, str) or not port.strip():
            raise ValueError('An explicit nonempty serial port is required')
        self.port = port.strip()
        self.bus = None

    def connect(self):
        from lerobot.robots.so_follower import SO101Follower, SO101FollowerConfig
        self.bus = SO101Follower(SO101FollowerConfig(port=self.port)).bus
        self.bus.connect()

    def close(self):
        if self.bus is not None and self.bus.is_connected:
            self.bus.disconnect(disable_torque=False)

    def read(self, joint):
        return int(self.bus.read('Present_Position', joint, normalize=False))

    def torque(self, joint):
        return int(self.bus.read('Torque_Enable', joint, normalize=False))

    def write(self, joint, target):
        self.bus.write('Goal_Position', joint, target, normalize=False)

    def enable(self, joint):
        self.bus.enable_torque(joint)

    def disable(self, joint):
        self.bus.disable_torque(joint)
