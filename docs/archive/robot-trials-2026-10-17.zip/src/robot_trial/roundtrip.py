"""One finite round trip per joint; mock by default, never a background loop."""
import argparse
import json
import math
import os
from pathlib import Path
import time
import tomllib
from .diagnostics import inspect_bus
from .safety import Limits
from .transport import JOINTS, LeRobotTransport, MockTransport


def run_joint(transport, joint, delta, limits, wait):
    limits.check(0, 0, delta)
    if any(transport.torque(name) != 0 for name in JOINTS):
        raise RuntimeError('All joints must be torque-off before each trial')
    start = transport.read(joint)
    target = limits.check(start, start, delta)
    try:
        transport.write(joint, start)
        transport.enable(joint)
        transport.write(joint, target)
        wait()
        forward = transport.read(joint)
        if abs(forward - start) > limits.max_offset_ticks:
            raise RuntimeError(f'{joint}: position escaped software envelope')
        # Return distance must also obey the configured command-step limit.
        if abs(start - forward) > limits.max_step_ticks:
            raise RuntimeError(f'{joint}: return distance exceeds configured step')
        transport.write(joint, start)
        wait()
        returned = transport.read(joint)
        if abs(returned - start) > limits.max_offset_ticks:
            raise RuntimeError(f'{joint}: return escaped software envelope')
        result = {'joint': joint, 'start_ticks': start, 'target_ticks': target,
                  'forward_actual_ticks': forward, 'return_target_ticks': start,
                  'return_actual_ticks': returned, 'forward_change_ticks': forward - start,
                  'return_error_ticks': returned - start}
    finally:
        transport.disable(joint)
        if transport.torque(joint) != 0:
            raise RuntimeError(f'{joint}: torque-off verification failed; stop trial')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--live', action='store_true')
    parser.add_argument('--port', default=os.getenv('FOLLOWER_PORT'))
    parser.add_argument('--arm-supported', action='store_true')
    parser.add_argument('--delta-ticks', type=int, required=True)
    parser.add_argument('--config', type=Path, default=Path('config/robot.toml'))
    args = parser.parse_args()
    config = tomllib.loads(args.config.read_text())
    dwell = config['trial']['dwell_seconds']
    if not isinstance(dwell, (int, float)) or not math.isfinite(dwell) or not 0 < dwell <= 10:
        parser.error('dwell_seconds must be finite and within (0, 10]')
    limits = {joint: Limits(config[joint]['max_offset_ticks'], config[joint]['max_step_ticks'])
              for joint in JOINTS}
    for limit in limits.values():
        limit.check(0, 0, args.delta_ticks)
    if args.live and (not args.port or not args.arm_supported):
        parser.error('Live trial requires explicit port and physically supported arm')
    if args.live:
        print('All 6 joints, one at a time, one round trip each. Raw ticks, unvalidated mechanical limits.', flush=True)
        print('Support the full arm throughout and keep physical power cutoff accessible.', flush=True)
        if input('Type ROUNDTRIP ALL to approve: ').strip() != 'ROUNDTRIP ALL':
            parser.exit(message='Cancelled\n')
    bus = LeRobotTransport(args.port) if args.live else MockTransport()
    if not args.live:
        bus.positions = {joint: config[joint]['mock_start_ticks'] for joint in JOINTS}
    wait = (lambda: time.sleep(dwell)) if args.live else (lambda: None)
    try:
        if args.live:
            bus.connect()
            diagnostic = inspect_bus(bus)
            print(json.dumps({'diagnostic_raw': diagnostic}), flush=True)
            for joint, values in diagnostic.items():
                start = values['Present_Position']
                low, high = values['Min_Position_Limit'], values['Max_Position_Limit']
                if values['Torque_Enable'] != 0 or values['Operating_Mode'] != 0:
                    raise RuntimeError(f'{joint}: torque or position mode preflight failed')
                if not low < high or not all(low <= p <= high for p in (start, start + args.delta_ticks)):
                    raise RuntimeError(f'{joint}: programmed position-limit check failed')
        for joint in JOINTS:
            result = run_joint(bus, joint, args.delta_ticks, limits[joint], wait)
            print(json.dumps({'mode': 'live' if args.live else 'mock', 'result': result,
                              'target_torque_off_verified': True}), flush=True)
    finally:
        if args.live:
            bus.close()


if __name__ == '__main__':
    main()
