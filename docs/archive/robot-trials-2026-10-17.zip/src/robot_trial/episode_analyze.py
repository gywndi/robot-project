"""Offline numerical analysis. Values retain source units; no motion export."""
import argparse
import csv
import json
import math
from pathlib import Path


def analyze(info, rows):
    names = info['features']['action']['names']
    state_names = info['features']['observation.state']['names']
    if not rows or not names or len(names) != len(set(names)):
        raise ValueError('Empty episode or invalid action names')
    episode = rows[0]['episode_index']
    previous = None
    for row in rows:
        if row['episode_index'] != episode:
            raise ValueError('Mixed episodes')
        for key, labels in (('action', names), ('observation.state', state_names)):
            if len(row[key]) != len(labels) or not all(math.isfinite(x) for x in row[key]):
                raise ValueError('Invalid joint vector')
        if not math.isfinite(row['timestamp']):
            raise ValueError('Nonfinite timestamp')
        if previous and (row['timestamp'] <= previous['timestamp'] or row['frame_index'] != previous['frame_index'] + 1):
            raise ValueError('Nonmonotonic time or missing/duplicate frames')
        previous = row
    summary = []
    for i, name in enumerate(names):
        values = [row['action'][i] for row in rows]
        steps = [abs(b-a) for a, b in zip(values, values[1:])]
        largest = max(steps, default=0)
        peak_index = steps.index(largest) + 1 if steps else 0
        summary.append({'joint_as_declared': name, 'source_index': i,
                        'first': values[0], 'last': values[-1],
                        'min': min(values), 'max': max(values),
                        'max_frame_delta': largest,
                        'max_delta_destination_frame': rows[peak_index]['frame_index']})
    return {'episode_index': episode, 'frames': len(rows),
            'duration_seconds': rows[-1]['timestamp'] - rows[0]['timestamp'],
            'source_robot_type': info.get('robot_type'),
            'declared_action_order': names, 'declared_state_order': state_names,
            'units': 'unverified; source values preserved',
            'first_action_all_zero': all(v == 0 for v in rows[0]['action']),
            'hardware_replay_allowed': False, 'joints': summary}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('--episode', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    info = json.loads((args.directory/'info.json').read_text())
    rows = json.loads(args.episode.read_text())
    report = analyze(info, rows)
    report['source'] = json.loads((args.directory/'source.json').read_text())
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output/'analysis.json').write_text(json.dumps(report, indent=2)+'\n')
    with (args.output/'action-source-values.csv').open('w', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['frame_index', 'timestamp', *report['declared_action_order']])
        writer.writerows([row['frame_index'], row['timestamp'], *row['action']] for row in rows)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
