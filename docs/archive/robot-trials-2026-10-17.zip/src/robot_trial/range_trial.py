"""Finite incremental trial with temporary SRAM settings and restoration."""
import argparse
import json
import math
import os
from pathlib import Path
import time
import tomllib
from .safety import Limits
from .transport import JOINTS, LeRobotTransport, MockTransport

SETTINGS = ('Torque_Limit', 'Goal_Velocity', 'Acceleration')


def validate_profile(cfg):
    if cfg['joint'] not in JOINTS:
        raise ValueError('Unknown joint')
    limits = Limits(cfg['max_offset_ticks'], cfg['max_step_ticks'])
    previous = 0
    if not cfg['offsets_ticks'] or cfg['offsets_ticks'][-1] != 0:
        raise ValueError('Finite path must end at start')
    for offset in cfg['offsets_ticks']:
        if type(offset) is not int:
            raise ValueError('Offsets must be integer ticks')
        limits.check(0, previous, offset - previous)
        previous = offset
    for key, high in (('torque_limit_raw', 1000), ('goal_velocity_raw', 32767), ('acceleration_raw', 254)):
        if type(cfg[key]) is not int or not 0 < cfg[key] <= high:
            raise ValueError(f'Invalid {key}')
    if type(cfg['tolerance_ticks']) is not int or not 0 <= cfg['tolerance_ticks'] < limits.max_step_ticks:
        raise ValueError('Tolerance must be smaller than step')
    for key in ('timeout_seconds', 'poll_seconds'):
        if not math.isfinite(cfg[key]) or cfg[key] <= 0:
            raise ValueError(f'Invalid {key}')
    return limits


def run_trial(transport, read_reg, write_reg, cfg, emit):
    limits = validate_profile(cfg)
    joint = cfg['joint']
    if any(transport.torque(name) != 0 for name in JOINTS):
        raise RuntimeError('All joints must initially be torque-off; support the arm')
    start = transport.read(joint)
    low, high = read_reg('Min_Position_Limit'), read_reg('Max_Position_Limit')
    if read_reg('Operating_Mode') != 0 or not low < high:
        raise RuntimeError('Position mode / programmed limits check failed')
    if not all(low <= start + offset <= high for offset in [0, *cfg['offsets_ticks']]):
        raise RuntimeError('Path exceeds programmed limits')
    original = {key: read_reg(key) for key in SETTINGS}
    desired = dict(zip(SETTINGS, (cfg['torque_limit_raw'], cfg['goal_velocity_raw'], cfg['acceleration_raw'])))
    if desired['Torque_Limit'] > min(original['Torque_Limit'], read_reg('Max_Torque_Limit')):
        raise RuntimeError('Trial may only reduce torque limit')
    emit({'start_ticks': start, 'original_settings_raw': original, 'trial_settings_raw': desired})
    touched = []
    try:
        transport.write(joint, start)
        for key, value in desired.items():
            touched.append(key)
            write_reg(key, value)
            if read_reg(key) != value:
                raise RuntimeError(f'{key}: write verification failed')
        transport.enable(joint)
        for offset in cfg['offsets_ticks']:
            actual = transport.read(joint)
            target = start + offset
            if abs(actual - start) > limits.max_offset_ticks + cfg['tolerance_ticks']:
                raise RuntimeError('Measured position escaped trial envelope')
            transport.write(joint, target)
            deadline = time.monotonic() + cfg['timeout_seconds']
            while True:
                actual = transport.read(joint)
                if abs(actual - start) > limits.max_offset_ticks + cfg['tolerance_ticks']:
                    raise RuntimeError('Measured position escaped trial envelope')
                if abs(actual - target) <= cfg['tolerance_ticks']:
                    break
                if time.monotonic() >= deadline:
                    raise TimeoutError('Target not reached; stop, do not increase torque or range')
                time.sleep(cfg['poll_seconds'])
            emit({'offset_ticks': offset, 'target_ticks': target, 'actual_ticks': actual})
    finally:
        # If torque-off fails, do not restore settings while the joint might be energized.
        transport.disable(joint)
        if transport.torque(joint) != 0:
            raise RuntimeError('Torque-off verification failed; physical intervention required')
        errors = []
        for key in reversed(touched):
            try:
                write_reg(key, original[key])
                if read_reg(key) != original[key]:
                    raise RuntimeError('Restore verification failed')
            except Exception as exc:
                errors.append(f'{key}: {exc}')
        emit({'torque_off_verified': True, 'settings_restore_errors': errors})
        if errors:
            raise RuntimeError('; '.join(errors))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--live', action='store_true')
    parser.add_argument('--port', default=os.getenv('FOLLOWER_PORT'))
    parser.add_argument('--arm-supported', action='store_true')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    cfg = tomllib.loads(args.config.read_text())
    validate_profile(cfg)
    if args.live and (not args.port or not args.arm_supported):
        parser.error('Live trial requires explicit port and supported arm')
    if args.output.exists():
        parser.error('Output already exists; choose a new file')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # Check log writability before hardware writes.
    with args.output.open('x') as log:
        def emit(record):
            record = {'mode': 'live' if args.live else 'mock', **record}
            line = json.dumps(record)
            print(line, flush=True)
            log.write(line + '\n')
            log.flush()
        bus = LeRobotTransport(args.port) if args.live else MockTransport(cfg['mock_start_ticks'])
        if args.live:
            print(f"Temporary settings and incremental path for {cfg['joint']}: {cfg}", flush=True)
            if input(f"Type RANGE {cfg['joint']} to approve: ").strip() != f"RANGE {cfg['joint']}":
                parser.exit(message='Cancelled\n')
            def read_reg(name):
                return int(bus.bus.read(name, cfg['joint'], normalize=False))
            def write_reg(name, value):
                if name not in SETTINGS:
                    raise ValueError('Only approved SRAM settings may be written')
                bus.bus.write(name, cfg['joint'], value, normalize=False)
        else:
            registers = {'Torque_Limit': 500, 'Max_Torque_Limit': 500, 'Goal_Velocity': 0,
                         'Acceleration': 254, 'Operating_Mode': 0,
                         'Min_Position_Limit': 0, 'Max_Position_Limit': 4095}
            read_reg = registers.__getitem__
            write_reg = registers.__setitem__
        try:
            if args.live:
                bus.connect()
            run_trial(bus, read_reg, write_reg, cfg, emit)
        finally:
            if args.live:
                bus.close()


if __name__ == '__main__':
    main()
