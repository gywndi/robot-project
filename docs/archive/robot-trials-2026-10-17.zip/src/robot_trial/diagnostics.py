"""Read-only motor register inspection. No setup or calibration writes."""
import argparse
import json
import os
from pathlib import Path
from .transport import LeRobotTransport, JOINTS

REGISTERS = ('Present_Position', 'Torque_Enable', 'Operating_Mode',
             'Min_Position_Limit', 'Max_Position_Limit', 'Homing_Offset',
             'Torque_Limit', 'Max_Torque_Limit', 'Goal_Velocity', 'Acceleration',
             'Present_Velocity', 'Present_Current', 'Present_Load',
             'Present_Voltage', 'Present_Temperature', 'CW_Dead_Zone', 'CCW_Dead_Zone')


def inspect_bus(transport):
    return {joint: {register: int(transport.bus.read(register, joint, normalize=False))
                    for register in REGISTERS} for joint in JOINTS}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', default=os.getenv('FOLLOWER_PORT'))
    parser.add_argument('--output', type=Path, help='Save raw diagnostic snapshot')
    args = parser.parse_args()
    if not args.port:
        parser.error('Explicit --port or FOLLOWER_PORT required')
    transport = LeRobotTransport(args.port)
    try:
        transport.connect()
        result = inspect_bus(transport)
        print(json.dumps(result))
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(result, indent=2) + '\n')
    finally:
        transport.close()


if __name__ == '__main__':
    main()
