import unittest
from robot_trial.controller import RobotController
from robot_trial.safety import Limits
from robot_trial.transport import MockTransport


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.bus = MockTransport()
        self.controller = RobotController(self.bus, Limits(20, 5))

    def test_startup_and_read_do_not_write(self):
        self.controller.positions()
        self.assertEqual(self.bus.commands, [])

    def test_approval_required(self):
        with self.assertRaises(PermissionError):
            self.controller.move('gripper', 5)
        self.assertEqual(self.bus.commands, [])

    def test_invalid_step_does_not_write(self):
        with self.assertRaises(ValueError):
            self.controller.move('gripper', 6, approved=True)
        self.assertEqual(self.bus.commands, [])

    def test_only_gripper_is_enabled_and_released(self):
        result = self.controller.move('gripper', 5, approved=True)
        self.assertEqual(result['actual_ticks'], 2475)
        self.assertEqual(self.bus.commands, [('goal', 'gripper', 2470),
            ('enable', 'gripper'), ('goal', 'gripper', 2475), ('disable', 'gripper')])

    def test_existing_torque_rejected_without_writes(self):
        self.bus.enabled['shoulder_lift'] = 1
        with self.assertRaises(RuntimeError):
            self.controller.move('gripper', 5, approved=True)
        self.assertEqual(self.bus.commands, [])

    def test_observation_failure_releases_only_gripper(self):
        def fail():
            raise KeyboardInterrupt
        self.controller.observe = fail
        with self.assertRaises(KeyboardInterrupt):
            self.controller.move('gripper', 5, approved=True)
        self.assertEqual(self.bus.commands[-1], ('disable', 'gripper'))

    def test_all_joints_supported_individually(self):
        from robot_trial.transport import JOINTS
        for joint in JOINTS:
            bus = MockTransport()
            RobotController(bus, Limits(20, 5)).move(joint, 5, approved=True)
            self.assertTrue(all(command[1] == joint for command in bus.commands))

    def test_live_transport_requires_explicit_port(self):
        from robot_trial.transport import LeRobotTransport
        for port in (None, '', '   '):
            with self.assertRaises(ValueError):
                LeRobotTransport(port)

    def test_relative_envelope(self):
        with self.assertRaises(ValueError):
            Limits(20, 5).check(2470, 2490, 5)


if __name__ == '__main__':
    unittest.main()
