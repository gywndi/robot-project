import unittest
from robot_trial.episode_analyze import analyze


class EpisodeAnalyzeTests(unittest.TestCase):
    def setUp(self):
        self.info = {'features': {'action': {'names': ['gripper']},
                                  'observation.state': {'names': ['gripper']}}}
        self.rows = [{'episode_index': 0, 'frame_index': i, 'timestamp': i / 30,
                      'action': [float(i)], 'observation.state': [float(i)]} for i in range(3)]

    def test_reports_deltas_without_permitting_replay(self):
        result = analyze(self.info, self.rows)
        self.assertEqual(result['joints'][0]['max_frame_delta'], 1)
        self.assertFalse(result['hardware_replay_allowed'])

    def test_rejects_nan_and_wrong_dimensions(self):
        self.rows[1]['action'] = [float('nan')]
        with self.assertRaises(ValueError):
            analyze(self.info, self.rows)
        self.rows[1]['action'] = []
        with self.assertRaises(ValueError):
            analyze(self.info, self.rows)

    def test_rejects_mixed_episodes_and_bad_timing(self):
        self.rows[1]['episode_index'] = 1
        with self.assertRaises(ValueError):
            analyze(self.info, self.rows)
        self.rows[1]['episode_index'] = 0
        self.rows[1]['timestamp'] = 0
        with self.assertRaises(ValueError):
            analyze(self.info, self.rows)
