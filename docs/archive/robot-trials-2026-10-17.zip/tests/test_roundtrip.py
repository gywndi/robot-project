import unittest
from robot_trial.roundtrip import run_joint
from robot_trial.safety import Limits
from robot_trial.transport import JOINTS, MockTransport


class RoundtripTests(unittest.TestCase):
    def test_all_joints_return_and_only_target_is_written(self):
        for joint in JOINTS:
            bus = MockTransport()
            result = run_joint(bus, joint, 5, Limits(20, 5), lambda: None)
            self.assertEqual(result['forward_change_ticks'], 5)
            self.assertEqual(result['return_error_ticks'], 0)
            self.assertEqual(bus.torque(joint), 0)
            self.assertTrue(all(cmd[1] == joint for cmd in bus.commands))

    def test_bad_step_has_no_writes(self):
        bus = MockTransport()
        with self.assertRaises(ValueError):
            run_joint(bus, 'gripper', 20, Limits(20, 5), lambda: None)
        self.assertEqual(bus.commands, [])

    def test_read_failure_disables_target_without_return_write(self):
        bus = MockTransport()
        def fail():
            raise OSError('Disconnected')
        with self.assertRaises(OSError):
            run_joint(bus, 'wrist_roll', 5, Limits(20, 5), fail)
        self.assertEqual(bus.commands[-1], ('disable', 'wrist_roll'))
        self.assertEqual(sum(cmd[0] == 'goal' for cmd in bus.commands), 2)
