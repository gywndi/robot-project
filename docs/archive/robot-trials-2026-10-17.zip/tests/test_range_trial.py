from pathlib import Path
import tomllib
import unittest
from robot_trial.range_trial import run_trial, validate_profile
from robot_trial.transport import MockTransport


class RangeTrialTests(unittest.TestCase):
    def setUp(self):
        self.cfg = tomllib.loads(Path('config/gripper-range-stage1.toml').read_text())
        self.bus = MockTransport(self.cfg['mock_start_ticks'])
        self.registers = {'Torque_Limit': 500, 'Max_Torque_Limit': 500, 'Goal_Velocity': 0,
                          'Acceleration': 254, 'Operating_Mode': 0,
                          'Min_Position_Limit': 2046, 'Max_Position_Limit': 3529}
        self.original = self.registers.copy()

    def run_path(self, emit=lambda record: None):
        run_trial(self.bus, self.registers.__getitem__, self.registers.__setitem__, self.cfg, emit)

    def test_path_returns_and_restores_settings(self):
        self.run_path()
        self.assertEqual(self.registers, self.original)
        self.assertEqual(self.bus.read('gripper'), self.cfg['mock_start_ticks'])
        self.assertEqual(self.bus.torque('gripper'), 0)
        self.assertTrue(all(cmd[1] == 'gripper' for cmd in self.bus.commands))

    def test_exception_releases_and_restores(self):
        def fail(record):
            if 'offset_ticks' in record:
                raise OSError('Log failure')
        with self.assertRaises(OSError):
            self.run_path(fail)
        self.assertEqual(self.registers, self.original)
        self.assertEqual(self.bus.torque('gripper'), 0)

    def test_reject_torque_increase_without_commands(self):
        self.cfg['torque_limit_raw'] = 600
        with self.assertRaises(RuntimeError):
            self.run_path()
        self.assertEqual(self.bus.commands, [])

    def test_reject_bad_path(self):
        self.cfg['offsets_ticks'] = [50, 0]
        with self.assertRaises(ValueError):
            validate_profile(self.cfg)
