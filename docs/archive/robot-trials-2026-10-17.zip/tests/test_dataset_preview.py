import unittest
from robot_trial.dataset_preview import build_preview
from robot_trial.transport import JOINTS


class PreviewTests(unittest.TestCase):
    def test_reordered_source_is_bounded_and_not_executable(self):
        names = list(reversed(JOINTS))
        info = {'features': {'action': {'names': names}, 'observation.state': {'names': names}}}
        rows = [{'episode_index': 0, 'frame_index': i, 'timestamp': i / 30,
                 'action': [float(i*j) for j in range(1, 7)],
                 'observation.state': [0.] * 6} for i in range(3)]
        result = build_preview(info, rows, dict.fromkeys(JOINTS, 20))
        self.assertFalse(result['hardware_replay_allowed'])
        self.assertIsNone(result['absolute_motor_targets'])
        self.assertEqual(result['frames'][0]['synthetic_offset_ticks']['gripper'], 0)
        self.assertEqual(result['frames'][-1]['synthetic_offset_ticks']['gripper'], 20)
