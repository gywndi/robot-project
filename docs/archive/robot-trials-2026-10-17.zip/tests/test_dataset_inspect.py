import unittest
from robot_trial.dataset_inspect import inspect_metadata
from robot_trial.transport import JOINTS


class DatasetInspectTests(unittest.TestCase):
    def test_reordered_names_map_explicitly_without_replay_permission(self):
        names = list(reversed(JOINTS))
        result = inspect_metadata({'features': {'action': {'names': names}}}, {})
        self.assertEqual(result['canonical_joint_to_source_index']['shoulder_pan'], 5)
        self.assertFalse(result['hardware_replay_allowed'])

    def test_missing_names_do_not_get_assumed_order(self):
        result = inspect_metadata({'features': {'action': {'shape': [6]}}}, {})
        self.assertIsNone(result['canonical_joint_to_source_index'])

    def test_suffixes_and_duplicates(self):
        info = {'features': {'action': {'names': [j + '.pos' for j in JOINTS]}}}
        self.assertEqual(inspect_metadata(info, {})['canonical_joint_to_source_index']['gripper'], 5)
        info['features']['action']['names'].append('gripper')
        with self.assertRaises(ValueError):
            inspect_metadata(info, {})
