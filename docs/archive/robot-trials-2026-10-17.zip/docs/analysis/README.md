# 공개 에피소드 분석 — 2026-10-17

고정된 공개 버전의 수치 파일에서 에피소드 0만 JSON으로 추출했습니다. 다운로드한 parquet 파일은 로컬 `logs/dataset-cache/`에 있으며 영상은 받지 않았습니다. 분석·모의 미리보기만 실행했고 USB 연결·모터 쓰기는 하지 않았습니다.

| 데이터 | 에피소드 0 | 발견 사항 | 현재 사용 범위 |
|---|---|---|---|
| gpudad/so101_pick_cube | 301 frames / 10.0초 | README 관절 나열과 info.json 배열 순서 불일치. 첫 action 6개 값 모두 0, 다음 프레임에 여러 축이 크게 변함 | 원본 수치 분석만. 출처 코드/좌표 의미 확인 전 실물 변환 보류 |
| lerobot/svla_so101_pickplace | 303 frames / 약 10.067초 | 이름은 SO101이지만 robot_type은 so100_follower. 단위·보정 대응 미확인 | 수치 분석 및 합성 상대변위 미리보기만 |

SO101 카드의 관절 나열은 배열 순서를 보증하지 않습니다. 어느 쪽이 실제 열 순서인지 임의로 추정하거나, 첫 zero action을 임의 삭제해 실행 가능하다고 판단하지 않습니다. 정확한 의미는 데이터 생성 코드/제작자 정보로 확인해야 합니다. 값의 범위만으로 radians/degrees/정규화 여부를 확정하지 않습니다.

각 폴더의 `analysis.json`은 원본 단위 그대로 min/max, 첫/마지막 action, 최대 프레임 변화량을 기록합니다. CSV도 원본 action의 선언된 순서를 유지합니다. 이 수치는 서보 raw ticks가 아닙니다.

## 모의 미리보기

`svla-episode0/synthetic-preview.json`은 시작 action을 기준으로 각 관절의 변화 패턴만 독립 축소한 결과입니다. 제한은 `config/dataset-preview.toml`의 별도 미리보기 설정(팔 관절 20, 집게 120 ticks)에서 읽습니다. 현재 Follower 위치를 읽거나 절대 목표 위치를 생성하지 않습니다.

독립 축소는 실제 기하학적 경로와 파지 동작을 바꾸므로 이 파일은 모터 재생용이 아닙니다. `hardware_replay_allowed=false`, `absolute_motor_targets=null`로 표시합니다. mock의 구조·진폭 검사 통과는 충돌 검증이나 집기 성공을 뜻하지 않습니다. 초기/최종 상대 자세가 같다는 보장도 없으며 자동 복귀 경로를 덧붙이지 않았습니다.

## 재실행

```bash
PYTHONPATH=src python -m robot_trial.episode_analyze data/reference/gpudad__so101_pick_cube --episode data/reference/gpudad__so101_pick_cube/episode-000000.json --output docs/analysis/so101-episode0
PYTHONPATH=src python -m robot_trial.dataset_preview data/reference/lerobot__svla_so101_pickplace --config config/dataset-preview.toml --output docs/analysis/svla-episode0/synthetic-preview.json
PYTHONPATH=src python -m unittest discover -s tests -q
```

검증: 23개 테스트 통과. 입력 NaN/차원 오류/혼합 에피소드/시간 역전/프레임 누락을 거부하며 합성 미리보기의 진폭 제한과 실물 재생 불허 표시를 확인했습니다.

## 실물 경로로 전환하기 위한 다음 조건

1. SO101 생성 코드나 제작자 설명으로 실제 action 열 순서와 단위·absolute/delta 의미 확인.
2. 로컬 관절의 원점·회전 방향·보정·작업 구간을 대응. 특히 중력 하중 관절에는 집게 토크 설정을 복사하지 않음.
3. 로컬에서 측정한 자세와 경로를 바탕으로 초기 진입·구간별 목표/속도/토크/횟수를 제시. 외부 action을 단순 clipping하여 대체하지 않음.
4. 구체적인 실물 조건에 동의를 받은 뒤 검증한 구간만 실행.

현재 동작 변환은 위 조건 전의 초안 단계입니다. 전체 팔 공개 데이터 재생 명령은 만들지 않았습니다.
