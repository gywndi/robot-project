# 기본 동작 데이터 출처와 활용

확인일: 2026-10-17. Leader는 이번 프로젝트에서 사용하지 않습니다. 이 문서는 자료 조사이며 데이터셋 전체 다운로드나 실물 재생을 수행하지 않았습니다.

## 참고 자료

| 출처 | 내용 | 이번 프로젝트에서 쓰는 방식 |
|---|---|---|
| [LeRobot 공식 기록·재생 예제](https://huggingface.co/docs/lerobot/il_robots) | 시연을 에피소드로 저장하고 재생하는 흐름 | 기록/검증/재생 구조 참고. Leader 연결이나 상위 API의 자동 설정·보정 절차는 그대로 실행하지 않음 |
| [lerobot/svla_so101_pickplace](https://huggingface.co/datasets/lerobot/svla_so101_pickplace) | 공개 pick/place 데이터. 카드에 50 episodes, 30 fps, 6개 관절 action/state와 두 영상 시점 명시 | 소규모 동작 분석 후보. 이름은 SO101이나 공개 카드의 robot_type은 so100_follower이므로 직접 호환된다고 판단하지 않음 |
| [gpudad/so101_pick_cube](https://huggingface.co/datasets/gpudad/so101_pick_cube) | 제작자 설명상 MuJoCo SO-101 큐브 집기/놓기 시뮬레이션 데이터 | 시퀀스·관절 궤적 참고. 시뮬레이션 action을 실물 raw ticks로 사용하지 않음 |
| [LeRobot 데이터 도구](https://huggingface.co/docs/lerobot/using_dataset_tools) | 데이터 조회·시각화·가공 도구 안내 | 설치 버전과의 API/데이터 포맷 호환 확인 후 읽기 전용 분석 |

공개 데이터셋은 출처의 README뿐 아니라 실제 `meta/info.json`, task/episode 정보, action 값의 의미를 확인해야 합니다. 관절 이름과 벡터 길이가 같아도 단위·원점·방향·정규화가 같다는 뜻은 아닙니다. 위 svla 데이터의 robot_type 불일치처럼 이름만으로 판단할 수 없습니다.

## 가져오는 순서

1. repo ID, 고정 revision, 라이선스, 생성 환경과 action 표현을 기록합니다.
2. 메타데이터와 한 에피소드만 대상으로 영상/궤적을 살펴봅니다.
3. 관절 이름·순서, absolute/delta action, raw ticks/degrees/radians/정규화 여부, gripper 표현, fps/시각을 확인합니다.
4. 단위나 보정 정보가 불충분하면 실물 변환을 보류하고 참고용으로만 둡니다.
5. 우리 장비의 제한·시작 자세·작업 공간을 반영한 로컬 경로를 별도로 생성하고 mock에서 검사합니다. 단순 clipping만으로 안전한 경로라고 판단하지 않습니다.
6. 명시적으로 승인한 구간만 실물에서 확인합니다. 외부 데이터 다운로드와 모터 재생을 하나의 명령으로 묶지 않습니다.

현재 BMT에는 공개 학습 데이터보다 우리 Follower에서 저장한 세 자세와 목표/실제 위치 로그가 우선입니다. 외부 데이터셋에는 우리 장비의 기계적 안전 한계나 적절한 토크 설정이 들어 있다고 가정하지 않습니다.

## 실제 메타데이터 확보 결과 — 2026-10-17

공개 저장소에서 버전을 고정하여 `info.json`, `stats.json`, 데이터 카드만 다운로드했습니다. 실제 궤적/영상은 아직 받지 않았습니다. 출처와 revision은 각 폴더의 `source.json`에 있습니다. 아래 수치는 카드의 예시보다 실제 내려받은 JSON을 기준으로 합니다.

| 항목 | svla_so101_pickplace | so101_pick_cube |
|---|---|---|
| 고정 revision | `f641879e22172be7e8161d5e6c1503c2d2feb657` | `0168e7bfb4d6c97dc1bfa085fa2fc1b78834993f` |
| robot_type | `so100_follower` | `so101` |
| 포맷 / FPS | v3.0 / 30 | v3.0 / 30 |
| 에피소드 / 프레임 | 50 / 11,939 | 10,993 / 1,456,901 |
| action 관절 순서 | shoulder_pan, shoulder_lift, elbow_flex, wrist_flex, wrist_roll, gripper (`.pos` 접미사) | elbow_flex, gripper, shoulder_lift, shoulder_pan, wrist_flex, wrist_roll |

저장 위치: `data/reference/lerobot__svla_so101_pickplace/`, `data/reference/gpudad__so101_pick_cube/`.

`robot_trial.dataset_inspect`를 구현했습니다. 네트워크·모터 연결 없이 저장된 메타데이터를 읽고 관절 이름별 인덱스 대응을 출력합니다. action 단위와 absolute/delta 의미는 미확인으로 표시하며, 하드웨어 재생 허용은 항상 false입니다. 현재의 검사 결과는 모터용 명령이나 검증된 궤적이 아닙니다.

```bash
PYTHONPATH=src python -m robot_trial.dataset_inspect data/reference/lerobot__svla_so101_pickplace
PYTHONPATH=src python -m robot_trial.dataset_inspect data/reference/gpudad__so101_pick_cube
```

다음 분석은 하나의 에피소드에 한정하여 관절별 시간 그래프·첫 자세·이동 폭·집게 전환 시점을 확인하는 것입니다. 이를 토대로 로컬에서 저장한 자세로 접근/집기/이동/놓기 시퀀스를 구성합니다. 데이터에 없는 동작 구간을 이미 분석했다고 간주하지 않습니다.

## 에피소드 분석으로 진행

이후 두 데이터의 에피소드 0을 추출해 실제 궤적을 분석했습니다. SO101 에피소드는 301프레임/10초이며 카드와 메타데이터의 관절 순서 차이 및 첫 action의 0 초기값이 확인됐습니다. 비교 데이터는 303프레임이며 제한된 합성 상대변위 미리보기만 생성했습니다. 최신 상세 결과와 재실행 명령은 [에피소드 분석](analysis/README.md)을 참고합니다. 메타데이터만 받았다는 앞 절의 설명은 초기 확보 시점의 기록입니다.
