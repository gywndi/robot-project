# 장비

- Apple Silicon Mac / macOS / Python 3.11
- SO-ARM101 Follower, Feetech 모터, USB 및 장비 표기에 맞는 전원
- SO-ARM101 Leader: 과거 USB 구분만 확인, 읽기/제어 검증 미완료

관절: shoulder_pan, shoulder_lift, elbow_flex, wrist_flex, wrist_roll, gripper.

USB 경로는 연결 상태에 따라 변하므로 저장소에 실제 값을 고정하지 않습니다. 연결할 때마다 식별하고 `--port` 또는 역할별 환경변수로 전달합니다. 카메라·말단 도구 등 추가 장치는 이번 BMT 초기 범위에 포함하지 않습니다.
