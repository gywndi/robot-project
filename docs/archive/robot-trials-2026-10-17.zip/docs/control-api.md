# 제어 API

`RobotController(transport, limits)`는 연결이나 쓰기를 수행하지 않습니다.

- `positions()`: 6개 관절의 raw tick 위치를 읽습니다.
- `move(joint, delta, approved=True)`: 시작 위치 기준 상대 이동을 한 번 수행합니다. 승인·설정·토크 상태를 검사하고 대상 관절만 제어합니다.
- `observe()`: mock에서는 대기하지 않습니다. 실물 CLI에서는 물리적 움직임 관찰 후 Enter를 기다립니다. 이 대기는 목표 도달 확인이나 타임아웃 구현이 아닙니다.

`LeRobotTransport`는 명시적 연결 때만 LeRobot을 import합니다. 포트는 생성자 인자로 받아야 합니다. `SO101Follower.connect()`는 설정 변경 가능성이 있어 사용하지 않고 `robot.bus.connect()`를 사용합니다. 종료 시에는 `bus.disconnect(disable_torque=False)`를 호출합니다. raw 값 읽기/쓰기는 `normalize=False`입니다.

이 API는 보정된 각도 제어, 충돌 방지, 연속 제어, 통신 실패 복구를 구현하지 않습니다.
