# 설치

대상: Apple Silicon macOS / Python 3.11. 저장소 루트에서 실행합니다.

```bash
python3.11 -m venv .venv
source .venv/bin/activate
PYTHONPATH=src python -m robot_trial.cli read
```

실물 테스트가 필요할 때만 LeRobot 환경을 준비합니다. 기존 작동 환경이 있다면 먼저 버전과 패키지 목록을 보관하고 임의 업그레이드는 피합니다.

```bash
python -m pip install 'lerobot[feetech]'
python -c "from lerobot.robots.so_follower import SO101Follower, SO101FollowerConfig; print('SO101 OK')"
python -c "import importlib.metadata as m; print(m.version('lerobot'))"
python -m pip freeze > requirements-freeze.txt
```

위 설치는 버전을 고정하지 않으므로 과거 환경과 같음을 보장하지 않습니다. 현재 코드는 `bus.disconnect(disable_torque=False)` 지원을 요구합니다. 연결 전에 설치 버전의 API를 확인합니다. 대화형 코드는 파일/모듈로 실행하고 stdin here-doc 방식으로 실행하지 않습니다.
