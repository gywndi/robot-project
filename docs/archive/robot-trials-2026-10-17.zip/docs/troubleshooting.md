# 문제 해결

- 포트 누락: 실제 연결 장치를 식별한 뒤 `--port` 또는 `FOLLOWER_PORT`를 전달합니다. 기본 포트는 없습니다.
- 포트 사용 중: SenseCraft나 다른 직렬 통신 프로그램을 종료합니다.
- SOFollowerRobot ImportError: 기존 검증 환경에서는 `lerobot.robots.so_follower`의 `SO101Follower`를 사용했습니다. 설치 버전을 확인합니다.
- input() EOFError: 프로그램을 파일 또는 `python -m robot_trial.cli`로 실행합니다.
- 기존 토크 ON: 자동 OFF하지 않습니다. 팔을 지지하고 별도 절차로 상태를 확인합니다.
- 위치값 변화와 물리 동작이 다름: 단위·회전 방향·기계적 상태를 확인하고 관찰을 기록합니다. 큰 이동으로 해결하려 하지 않습니다.
- 손목 과회전: 이전 약 360° 회전 원인은 미해결입니다. 실물 반복 시험 전 진단합니다.
