"""Compatibility entry point. Default action is read, default transport is mock."""
from robot_trial.cli import main

if __name__ == '__main__':
    main()
