"""Compatibility entry point. Use `move` for one selected-joint trial; mock by default."""
from robot_trial.cli import main

if __name__ == '__main__':
    main()
